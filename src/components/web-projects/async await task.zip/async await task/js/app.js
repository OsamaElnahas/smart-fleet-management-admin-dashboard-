import { GetCountry } from "./api.js";

GetCountry("egypt");